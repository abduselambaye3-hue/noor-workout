# NOOR Workout v2.9 — animated coach Android prototype

An offline, dark-and-cyan NOOR Workout Android prototype with 16 included exercise animation sequences. The animation images are illustrative and should be reviewed for movement accuracy before public release.

## Features

- 16 animated exercise previews bundled **inside the offline HTML asset** and accompanied by form notes
- Searchable exercise library, coach screen, and four-day dumbbell home plan
- Play/pause and half-speed movement preview controls
- Rep/set/rest guidance, workout logging and local progress history
- No account or network access required; the WebView stores workout state locally

## Build debug APK with GitHub Actions

1. Upload the **contents** of this project (not the parent folder or ZIP file alone) into the root of the repository.
2. The build workflow is at `.github/workflows/android.yml` and starts on a push to `main`; it also supports manual runs from **Actions > Build NOOR Workout v2.9 APK > Run workflow**.
3. After a successful workflow run, download the `NOORWorkout-v2.9-debug-apk` artifact and unzip it to obtain `app-debug.apk`.

## Build with Android Studio

Open this root folder as a Gradle project. Use JDK 17, Android SDK Platform 35 and Android Gradle Plugin 8.6.1. Choose **Build > Build APK(s)**. The output will be `app/build/outputs/apk/debug/app-debug.apk`.

**Version:** 2.9.0 (`versionCode` 29), package `com.noor.workout`.

## Notes and limitations

- This is a test/debug app, not a signed production release.
- The 16 animations are not independently biomechanically verified.
- The character resemblance is illustrative, and some generated frames may vary.
- Workouts and profile data are stored on the device; no cloud sync.
- Automated GitHub build and installation on a real Android device remain unverified until a successful workflow run.
