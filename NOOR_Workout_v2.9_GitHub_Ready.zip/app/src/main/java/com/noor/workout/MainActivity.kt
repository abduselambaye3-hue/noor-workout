package com.noor.workout

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest

/** Offline, no-permissions Android shell for the NOOR v2.9 offline animated exercise prototype. */
class MainActivity : Activity() {
    private lateinit var app: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#061016")
        window.navigationBarColor = Color.parseColor("#061016")
        app = WebView(this).apply {
            setBackgroundColor(Color.parseColor("#061016"))
            settings.javaScriptEnabled = true // required for locally bundled app logic
            settings.domStorageEnabled = true  // local-only profile and workout log
            settings.allowFileAccess = true    // app/src/main/assets/index.html
            settings.allowContentAccess = false
            settings.allowFileAccessFromFileURLs = false
            settings.allowUniversalAccessFromFileURLs = false
            settings.setSupportZoom(false)
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    return request?.url?.toString() != "file:///android_asset/index.html"
                }
            }
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(app)
    }

    @Deprecated("For compatibility with Android API 24+")
    override fun onBackPressed() {
        app.evaluateJavascript("window.noorNativeBack ? window.noorNativeBack() : false") { handled ->
            if (handled != "true") finish()
        }
    }

    override fun onDestroy() {
        app.destroy()
        super.onDestroy()
    }
}
