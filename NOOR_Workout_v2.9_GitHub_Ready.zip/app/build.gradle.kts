plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.noor.workout"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.noor.workout"
        minSdk = 24
        targetSdk = 34
        versionCode = 29
        versionName = "2.9.0"
    }
    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
